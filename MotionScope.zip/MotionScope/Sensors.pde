// Sensors.pde
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

Context appContext;
SensorManager sensorManager;
Sensor accelerometer;
AccelerometerListener accelerometerListener;

volatile float rawAx = 0;
volatile float rawAy = 0;
volatile float rawAz = 0;

float ax = 0;
float ay = 0;
float az = 0;
float accelMagnitude = 0;
boolean sensorAvailable = false;
boolean sensorRegistered = false;

void initSensors() {
  appContext = getContext();
  sensorManager = (SensorManager) appContext.getSystemService(Context.SENSOR_SERVICE);
  accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
  accelerometerListener = new AccelerometerListener();
  sensorAvailable = accelerometer != null;
  registerSensors();
}

void registerSensors() {
  if (!sensorAvailable || sensorManager == null || accelerometerListener == null) return;
  if (sensorRegistered) return;

  sensorManager.registerListener(
    accelerometerListener,
    accelerometer,
    SensorManager.SENSOR_DELAY_GAME
  );
  sensorRegistered = true;
}

void unregisterSensors() {
  if (sensorManager != null && accelerometerListener != null && sensorRegistered) {
    sensorManager.unregisterListener(accelerometerListener);
    sensorRegistered = false;
  }
}

void updateSensorModel() {
  if (freezeValues) return;

  ax += (rawAx - ax) * smoothing;
  ay += (rawAy - ay) * smoothing;
  az += (rawAz - az) * smoothing;
  accelMagnitude = sqrt(ax * ax + ay * ay + az * az);
}

class AccelerometerListener implements SensorEventListener {
  public void onSensorChanged(SensorEvent event) {
    rawAx = event.values[0];
    rawAy = event.values[1];
    rawAz = event.values[2];
  }

  public void onAccuracyChanged(Sensor sensor, int accuracy) {
  }
}

// Освобождаем сенсор в фоне, чтобы не расходовать батарею.
public void onPause() {
  unregisterSensors();
  super.onPause();
}

public void onResume() {
  super.onResume();
  registerSensors();
}
