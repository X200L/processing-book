// UI.pde
float u() {
  // Наша условная единица интерфейса зависит от меньшей стороны экрана.
  return min(width, height) / 100.0;
}

void drawHeader() {
  float m = 5 * u();
  fill(245);
  textSize(6.0 * u());
  text(appTitle, m, 9 * u());

  fill(150, 160, 176);
  textSize(3.3 * u());
  text(sensorAvailable ? "accelerometer connected" : "accelerometer not found", m, 14 * u());
}

void drawSensorCards() {
  float m = 5 * u();
  float gap = 2 * u();
  float cardW = (width - 2 * m - 2 * gap) / 3.0;
  float y = 19 * u();

  drawValueCard(m, y, cardW, "X", ax);
  drawValueCard(m + cardW + gap, y, cardW, "Y", ay);
  drawValueCard(m + 2 * (cardW + gap), y, cardW, "Z", az);
}

void drawValueCard(float x, float y, float w, String label, float value) {
  float h = 18 * u();
  noStroke();
  fill(31, 35, 45);
  rect(x, y, w, h, 3 * u());

  fill(154, 166, 188);
  textSize(3.0 * u());
  text(label, x + 3 * u(), y + 5 * u());

  fill(245);
  textSize(4.2 * u());
  text(nf(value, 1, 2), x + 3 * u(), y + 12 * u());
}

void drawMotionBubble() {
  float cx = width / 2.0;
  float cy = 53 * u();
  float radius = 15 * u();

  noFill();
  stroke(73, 82, 102);
  strokeWeight(max(1, 0.4 * u()));
  circle(cx, cy, radius * 2);
  line(cx - radius, cy, cx + radius, cy);
  line(cx, cy - radius, cx, cy + radius);

  float bx = cx + constrain(-ax / 10.0, -1, 1) * radius * 0.8;
  float by = cy + constrain( ay / 10.0, -1, 1) * radius * 0.8;

  noStroke();
  fill(80, 200, 255);
  circle(bx, by, 4.2 * u());

  fill(180);
  textSize(3.0 * u());
  textAlign(CENTER, BASELINE);
  text("|a| = " + nf(accelMagnitude, 1, 2) + " m/s²", cx, cy + radius + 6 * u());
  textAlign(LEFT, BASELINE);
}

void drawHistoryGraph() {
  float m = 5 * u();
  float x = m;
  float y = 75 * u();
  float w = width - 2 * m;
  float h = 15 * u();

  noStroke();
  fill(31, 35, 45);
  rect(x, y, w, h, 3 * u());

  stroke(80, 200, 255);
  strokeWeight(max(1, 0.35 * u()));
  noFill();
  beginShape();
  for (int i = 0; i < HISTORY_SIZE; i++) {
    int idx = (historyHead + i) % HISTORY_SIZE;
    float px = map(i, 0, HISTORY_SIZE - 1, x + 2 * u(), x + w - 2 * u());
    float py = map(constrain(history[idx], 0, 20), 0, 20, y + h - 2 * u(), y + 2 * u());
    vertex(px, py);
  }
  endShape();
}

void drawFooter() {
  fill(135, 145, 160);
  textSize(2.8 * u());
  String state = freezeValues ? "PAUSED — tap to resume" : "LIVE — tap to freeze";
  textAlign(CENTER, BASELINE);
  text(state, width / 2.0, height - 4 * u());
  textAlign(LEFT, BASELINE);
}
