# MotionScope — Processing for Android example

Учебный проект из книги «Processing for Android: практическая книга разработчика».

## Что показывает

- запуск Processing-sketch как Android-приложения;
- прямой доступ к Android Sensor API;
- работу `getContext()`;
- регистрацию/освобождение `SensorEventListener` в lifecycle;
- адаптивный интерфейс без фиксированных пикселей;
- `touchStarted()`;
- загрузку `data/config.json`;
- простую фильтрацию и историю значений.

## Как запустить

1. Установите Processing 4 и Android Mode.
2. Откройте файл `MotionScope.pde` из папки `MotionScope`.
3. Переключитесь в Android Mode.
4. Подключите телефон с включённым USB debugging.
5. Убедитесь, что `adb devices` показывает устройство со статусом `device`.
6. Запустите `Run on Device`.

Проект не требует dangerous permissions: акселерометр доступен без runtime-разрешения.

## Управление

Коснитесь экрана, чтобы заморозить/разморозить текущие значения.
