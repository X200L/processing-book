// Config.pde
void loadAppConfig() {
  try {
    JSONObject config = loadJSONObject("config.json");
    if (config == null) return;

    if (config.hasKey("title")) {
      appTitle = config.getString("title");
    }

    if (config.hasKey("smoothing")) {
      smoothing = constrain(config.getFloat("smoothing"), 0.01, 1.0);
    }
  }
  catch (Exception e) {
    println("Config error: " + e.getMessage());
  }
}
