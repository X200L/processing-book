// MotionScope.pde
// Учебный проект для Processing for Android.
// Показывает: адаптивный UI, сенсор Android, lifecycle, touch и data/config.json.

PFont uiFont;
String appTitle = "MotionScope";
float smoothing = 0.14;
boolean freezeValues = false;

void setup() {
  fullScreen(P2D);
  orientation(PORTRAIT);
  uiFont = createFont("SansSerif", 18 * displayDensity);
  textFont(uiFont);
  textAlign(LEFT, BASELINE);

  loadAppConfig();
  initHistory();
  initSensors();
}

void draw() {
  updateSensorModel();
  pushHistory(accelMagnitude);

  background(18, 20, 26);
  drawHeader();
  drawSensorCards();
  drawMotionBubble();
  drawHistoryGraph();
  drawFooter();
}

// На Android touchStarted() вызывается при начале касания.
// В примере касание замораживает/размораживает отображаемые значения.
void touchStarted() {
  freezeValues = !freezeValues;
}
