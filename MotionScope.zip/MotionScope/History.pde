// History.pde
final int HISTORY_SIZE = 120;
float[] history = new float[HISTORY_SIZE];
int historyHead = 0;

void initHistory() {
  for (int i = 0; i < HISTORY_SIZE; i++) history[i] = 0;
}

void pushHistory(float value) {
  if (freezeValues) return;
  history[historyHead] = value;
  historyHead = (historyHead + 1) % HISTORY_SIZE;
}
